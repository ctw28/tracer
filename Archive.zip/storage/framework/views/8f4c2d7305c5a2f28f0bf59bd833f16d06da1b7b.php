<?php $__env->startSection('content'); ?>
<!-- Form Row Start -->
<section class="scroll-section">
    <div class="card mb-2">
        <div class="card-body d-flex flex-column">
            <h4>Identitas Alumni</h4>
            <span class="" style="list-style-type:none">Nim : <span id=nim></span></span>
            <span style="list-style-type:none">Nama : <span id=nama></span></span>
            <span style="list-style-type:none">Prodi : <span id=prodi></span></span>
        </div>
    </div>
</section>
<section class="scroll-section">

    <div class="card mb-5">
        <div class="card-body">
            <h2>Detail Jawaban</h2>
            <table class="table table-bordered table-hover mt-4">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Bagian</th>
                        <th>Pertanyaan</th>
                        <th>Jawaban</th>
                    </tr>
                </thead>
                <tbody id="show-data-table">
                    <?php $__currentLoopData = $bagian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td rowspan="<?php echo e((count($item->pertanyaan)+1)); ?>"><?php echo e($index+1); ?></td>
                        <td rowspan="<?php echo e((count($item->pertanyaan)+1)); ?>"><?php echo e($item->step_kode); ?> - <?php echo e($item->step_nama); ?></td>
                    </tr>

                    <?php $__currentLoopData = $item->pertanyaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $tanya): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="1"><?php echo e($tanya->pertanyaan); ?></td>
                        <?php if(count($tanya->jawaban)!==0): ?>
                        <td><?php echo e($tanya->jawaban[0]->jawaban); ?></td>
                        <?php else: ?>
                        <td>-</td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>
</section>
<!-- Form Row End -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    showData()
    async function showData() {
        let dataSend = new FormData()

        dataSend.append('iddata', JSON.stringify("<?php echo e($user->name); ?>"))
        response = await fetch('https://sia.iainkendari.ac.id/alumni/tracer/data-alumni', {
            method: "POST",
            body: dataSend
        })
        responseMessage = await response.json()
        document.querySelector("#nim").innerText = responseMessage.data[0].nim
        document.querySelector("#nama").innerText = responseMessage.data[0].nama
        document.querySelector("#prodi").innerText = responseMessage.data[0].prodi
        console.log();

    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bandrigotalai/Documents/My Personal File/Project/IAIN KENDARI/tracer/resources/views/admin/data-alumni-jawaban.blade.php ENDPATH**/ ?>