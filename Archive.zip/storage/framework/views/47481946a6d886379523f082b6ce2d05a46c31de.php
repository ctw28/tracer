<?php $__env->startSection('content'); ?>

<section class="scroll-section" id="basic">
    <!-- Basic Start -->
    <div class="card mb-5">
        <div class="card-body">
            <h3 class="mb-4"><?php echo e($bagianData->step_kode); ?>. <?php echo e($bagianData->step_nama); ?></h3>
            <form action="<?php echo e(route('user.store.jawaban',$bagianData->id)); ?>" method="post" enctype="multipart/form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="step_id" value="<?php echo e($bagianData->id); ?>">
                <input type="hidden" name="awal" value="<?php echo e($awal); ?>">
                <input type="hidden" name="akhir" value="<?php echo e($akhir); ?>">
                <?php $__currentLoopData = $bagianData->pertanyaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tanya): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $tanya->form; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                <?php if($akhir==true): ?>
                <button type="button" class="btn btn-dark" onclick="kembali('<?php echo e($bagianData->bagianDirect->step_id_direct_back); ?>')">Kembali</button>
                <button type="submit" class="btn btn-warning" onclick="return confirm('Yakin Selesai?')">Selesai</button>
                <?php else: ?>
                <?php if($awal==false): ?>
                <button type="button" class="btn btn-dark" onclick="kembali('<?php echo e($bagianData->bagianDirect->step_id_direct_back); ?>')">Kembali</button>
                <?php endif; ?>
                <button type="submit" class="btn btn-primary">Simpan dan Lanjut</button>
                <?php endif; ?>
            </form>
        </div>
    </div>
</section>
<!-- Basic End -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    async function kembali(bagianId) {
        let urlBack = "<?php echo e(route('user.show.pertanyaan',':bagianId')); ?>"
        urlBack = urlBack.replace(':bagianId', bagianId)
        window.location.replace(urlBack);

        // alert(bagianId)
    }

    function removeTextInput(event, pertanyaanId) {
        if (event.target.parentNode.parentNode.contains(document.querySelector("#lainnya_" + pertanyaanId))) {
            document.querySelector("#lainnya_" + pertanyaanId).remove();
        }
    }

    function showTextInput(event, pertanyaanId) {
        console.log(`${event.target.type} - ${event.target.checked}`);
        if (event.target.type === "checkbox") {
            if (event.target.checked == false)
                return removeTextInput(event, pertanyaanId)
        }
        if (event.target.type === "select-one") {
            if (event.target.value == "lainnya") {
                if (!event.target.parentNode.parentNode.contains(document.querySelector("#lainnya_" + pertanyaanId))) {
                    let input = document.createElement('input');
                    input.className = 'form-control'
                    input.name = `lainnya[${pertanyaanId}]`
                    input.id = `lainnya_${pertanyaanId}`
                    // event.target.removeAttribute('onclick')
                    event.target.closest('div').after(input)
                    return
                }
            } else {
                return removeTextInput(event, pertanyaanId)
            }
        }
        if (!event.target.parentNode.parentNode.contains(document.querySelector("#lainnya_" + pertanyaanId))) {
            let input = document.createElement('input');
            input.className = 'form-control'
            input.name = `lainnya[${pertanyaanId}]`
            input.id = `lainnya_${pertanyaanId}`
            input.setAttribute('required', 'required')
            // event.target.removeAttribute('onclick')
            event.target.closest('div').after(input);
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.template-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bandrigotalai/Documents/My Personal File/Project/IAIN KENDARI/tracer/resources/views/user/show-pertanyaan.blade.php ENDPATH**/ ?>