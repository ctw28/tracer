<?php $__env->startSection('content'); ?>

<!-- Form Row Start -->
<section class="scroll-section" id="formRow">
    <h2 class="small-title">Daftar Pertanyaan</h2>
    <div class="card mb-5">
        <div class="card-body">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Kodeaaa</th>
                        <th scope="col">Urutan</th>
                        <th scope="col">Deskripsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $stepDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row">1</th>
                        <td><?php echo e($step->step_kode); ?></td>
                        <td><?php echo e($step->step_urutan); ?></td>
                        <td><?php echo e($step->step_nama); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<!-- Form Row End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bandrigotalai/Documents/My Personal File/Project/IAIN KENDARI/tracer/resources/views/admin/step-pertanyaan.blade.php ENDPATH**/ ?>