<?php $__env->startSection('content'); ?>

<!-- Form Row Start -->
<section class="scroll-section" id="formRow">
    <div class="col-auto d-flex mb-2">
        <a href="<?php echo e(route('admin.form.create')); ?>" class="btn btn-primary btn-icon btn-icon-start ms-1">
            <i data-cs-icon="plus"></i>
            <span>Tambah Bagian</span>
        </a>
        <a href="<?php echo e(route('admin.bagian.set.urutan')); ?>" class="btn btn-secondary btn-icon btn-icon-start ms-1">
            <i data-cs-icon="gear"></i>
            <span>Pengaturan Redirect</span>
        </a>

    </div>
    <div class="card mb-5">
        <div class="card-body">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Kode</th>
                        <th scope="col">Deskripsi</th>
                        <!-- <th scope="col">Urutan</th> -->
                        <th scope="col">Pertanyaan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $stepData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($index+1); ?></th>
                        <td><?php echo e($step->step_kode); ?></td>
                        <td><?php echo e($step->step_nama); ?></td>
                        <!-- <td><?php echo e($step->step_urutan); ?></td> -->
                        <td>
                            <a href="<?php echo e(route('admin.form.show',$step->id)); ?>" class="btn btn-light btn-sm">Kelola</a>
                            <a href="<?php echo e(route('admin.form.show',$step->id)); ?>" class="btn btn-warning btn-sm">Ubah</a>
                            <a href="<?php echo e(route('admin.form.show',$step->id)); ?>" class="btn btn-danger btn-sm">Hapus</a>
                        </td>
                    </tr>
                    <?php $__currentLoopData = $step->stepChild; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th></th>
                        <td><?php echo e($child->step_kode); ?></td>
                        <td><?php echo e($child->step_nama); ?></td>
                        <!-- <td><?php echo e($child->step_urutan); ?></td> -->
                        <td>
                            <a href="<?php echo e(route('admin.form.show',$child->id)); ?>" class="btn btn-light btn-sm">Kelola</a>
                            <a href="<?php echo e(route('admin.form.show',$child->id)); ?>" class="btn btn-warning btn-sm">Ubah</a>
                            <a href="<?php echo e(route('admin.form.show',$child->id)); ?>" class="btn btn-danger btn-sm">Hapus</a>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<!-- Form Row End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bandrigotalai/Documents/My Personal File/Project/IAIN KENDARI/tracer/resources/views/admin/form-index.blade.php ENDPATH**/ ?>