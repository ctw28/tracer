<!DOCTYPE html>
<html lang="en" data-footer="true" data-override='{"attributes":{"layout": "boxed"}}'>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>Acorn Admin Template | Portfolio Home Page</title>
    <meta name="description" content="Portfolio Home Page" />
    <!-- Favicon Tags Start -->
    <link rel="apple-touch-icon-precomposed" sizes="57x57" href="img/favicon/apple-touch-icon-57x57.png" />
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="img/favicon/apple-touch-icon-114x114.png" />
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="img/favicon/apple-touch-icon-72x72.png" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="img/favicon/apple-touch-icon-144x144.png" />
    <link rel="apple-touch-icon-precomposed" sizes="60x60" href="img/favicon/apple-touch-icon-60x60.png" />
    <link rel="apple-touch-icon-precomposed" sizes="120x120" href="img/favicon/apple-touch-icon-120x120.png" />
    <link rel="apple-touch-icon-precomposed" sizes="76x76" href="img/favicon/apple-touch-icon-76x76.png" />
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="img/favicon/apple-touch-icon-152x152.png" />
    <link rel="icon" type="image/png" href="img/favicon/favicon-196x196.png" sizes="196x196" />
    <link rel="icon" type="image/png" href="img/favicon/favicon-96x96.png" sizes="96x96" />
    <link rel="icon" type="image/png" href="img/favicon/favicon-32x32.png" sizes="32x32" />
    <link rel="icon" type="image/png" href="img/favicon/favicon-16x16.png" sizes="16x16" />
    <link rel="icon" type="image/png" href="img/favicon/favicon-128.png" sizes="128x128" />
    <meta name="application-name" content="&nbsp;" />
    <meta name="msapplication-TileColor" content="#FFFFFF" />
    <meta name="msapplication-TileImage" content="img/favicon/mstile-144x144.png" />
    <meta name="msapplication-square70x70logo" content="img/favicon/mstile-70x70.png" />
    <meta name="msapplication-square150x150logo" content="img/favicon/mstile-150x150.png" />
    <meta name="msapplication-wide310x150logo" content="img/favicon/mstile-310x150.png" />
    <meta name="msapplication-square310x310logo" content="img/favicon/mstile-310x310.png" />
    <!-- Favicon Tags End -->
    <!-- Font Tags Start -->
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@300;400;600&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;700&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="font/CS-Interface/style.css" />
    <!-- Font Tags End -->
    <!-- Vendor Styles Start -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>css/vendor/bootstrap.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>css/vendor/OverlayScrollbars.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>css/vendor/baguetteBox.min.css" />
    <!-- Vendor Styles End -->
    <!-- Template Base Styles Start -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>css/styles.css" />
    <!-- Template Base Styles End -->

    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>css/main.css" />
    <script src="<?php echo e(asset('/')); ?>js/base/loader.js"></script>
</head>

<body>
    <div id="root">
        <div id="nav" class="nav-container d-flex">
            <div class="nav-content d-flex">
                <!-- Logo Start -->
                <div class="logo position-relative">
                    <a href="Dashboards.Default.html">
                        <!-- Logo can be added directly -->
                        <!-- <img src="img/logo/logo-white.svg" alt="logo" /> -->

                        <!-- Or added via css to provide different ones for different color themes -->
                        <div class="img"></div>
                    </a>
                </div>
                <!-- Logo End -->

                <!-- Language Switch Start -->
                <div class="language-switch-container">
                    <button class="btn btn-empty language-button dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">EN</button>
                    <div class="dropdown-menu">
                        <a href="#" class="dropdown-item">DE</a>
                        <a href="#" class="dropdown-item active">EN</a>
                        <a href="#" class="dropdown-item">ES</a>
                    </div>
                </div>
                <!-- Language Switch End -->

                <!-- User Menu Start -->
                <div class="user-container d-flex">
                    <a href="#" class="d-flex user position-relative" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img class="profile" alt="profile" src="img/profile/profile-9.jpg" />
                        <div class="name">Lisa Jackson</div>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end user-menu wide">
                        <div class="row mb-3 ms-0 me-0">
                            <div class="col-12 ps-1 mb-2">
                                <div class="text-extra-small text-primary">ACCOUNT</div>
                            </div>
                            <div class="col-6 ps-1 pe-1">
                                <ul class="list-unstyled">
                                    <li>
                                        <a href="#">User Info</a>
                                    </li>
                                    <li>
                                        <a href="#">Preferences</a>
                                    </li>
                                    <li>
                                        <a href="#">Calendar</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-6 pe-1 ps-1">
                                <ul class="list-unstyled">
                                    <li>
                                        <a href="#">Security</a>
                                    </li>
                                    <li>
                                        <a href="#">Billing</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="row mb-1 ms-0 me-0">
                            <div class="col-12 p-1 mb-2 pt-2">
                                <div class="text-extra-small text-primary">APPLICATION</div>
                            </div>
                            <div class="col-6 ps-1 pe-1">
                                <ul class="list-unstyled">
                                    <li>
                                        <a href="#">Themes</a>
                                    </li>
                                    <li>
                                        <a href="#">Language</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-6 pe-1 ps-1">
                                <ul class="list-unstyled">
                                    <li>
                                        <a href="#">Devices</a>
                                    </li>
                                    <li>
                                        <a href="#">Storage</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="row mb-1 ms-0 me-0">
                            <div class="col-12 p-1 mb-3 pt-3">
                                <div class="separator-light"></div>
                            </div>
                            <div class="col-6 ps-1 pe-1">
                                <ul class="list-unstyled">
                                    <li>
                                        <a href="#">
                                            <i data-cs-icon="help" class="me-2" data-cs-size="17"></i>
                                            <span class="align-middle">Help</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i data-cs-icon="file-text" class="me-2" data-cs-size="17"></i>
                                            <span class="align-middle">Docs</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-6 pe-1 ps-1">
                                <ul class="list-unstyled">
                                    <li>
                                        <a href="#">
                                            <i data-cs-icon="gear" class="me-2" data-cs-size="17"></i>
                                            <span class="align-middle">Settings</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i data-cs-icon="logout" class="me-2" data-cs-size="17"></i>
                                            <span class="align-middle">Logout</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- User Menu End -->

                <!-- Icons Menu Start -->
                <ul class="list-unstyled list-inline text-center menu-icons">
                    <li class="list-inline-item">
                        <a href="#" data-bs-toggle="modal" data-bs-target="#searchPagesModal">
                            <i data-cs-icon="search" data-cs-size="18"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#" id="pinButton" class="pin-button">
                            <i data-cs-icon="lock-on" class="unpin" data-cs-size="18"></i>
                            <i data-cs-icon="lock-off" class="pin" data-cs-size="18"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#" id="colorButton">
                            <i data-cs-icon="light-on" class="light" data-cs-size="18"></i>
                            <i data-cs-icon="light-off" class="dark" data-cs-size="18"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#" data-bs-toggle="dropdown" data-bs-target="#notifications" aria-haspopup="true" aria-expanded="false" class="notification-button">
                            <div class="position-relative d-inline-flex">
                                <i data-cs-icon="bell" data-cs-size="18"></i>
                                <span class="position-absolute notification-dot rounded-xl"></span>
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end wide notification-dropdown scroll-out" id="notifications">
                            <div class="scroll">
                                <ul class="list-unstyled border-last-none">
                                    <li class="mb-3 pb-3 border-bottom border-separator-light d-flex">
                                        <img src="img/profile/profile-1.jpg" class="me-3 sw-4 sh-4 rounded-xl align-self-center" alt="..." />
                                        <div class="align-self-center">
                                            <a href="#">Joisse Kaycee just sent a new comment!</a>
                                        </div>
                                    </li>
                                    <li class="mb-3 pb-3 border-bottom border-separator-light d-flex">
                                        <img src="img/profile/profile-2.jpg" class="me-3 sw-4 sh-4 rounded-xl align-self-center" alt="..." />
                                        <div class="align-self-center">
                                            <a href="#">New order received! It is total $147,20.</a>
                                        </div>
                                    </li>
                                    <li class="mb-3 pb-3 border-bottom border-separator-light d-flex">
                                        <img src="img/profile/profile-3.jpg" class="me-3 sw-4 sh-4 rounded-xl align-self-center" alt="..." />
                                        <div class="align-self-center">
                                            <a href="#">3 items just added to wish list by a user!</a>
                                        </div>
                                    </li>
                                    <li class="pb-3 pb-3 border-bottom border-separator-light d-flex">
                                        <img src="img/profile/profile-6.jpg" class="me-3 sw-4 sh-4 rounded-xl align-self-center" alt="..." />
                                        <div class="align-self-center">
                                            <a href="#">Kirby Peters just sent a new message!</a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                </ul>
                <!-- Icons Menu End -->

                <!-- Menu Start -->
                <div class="menu-container flex-grow-1">
                    <ul id="menu" class="menu">
                        <li>
                            <a href="#dashboards" data-href="Dashboards.html">
                                <i data-cs-icon="home" class="icon" data-cs-size="18"></i>
                                <span class="label">Dashboards</span>
                            </a>
                            <ul id="dashboards">
                                <li>
                                    <a href="Dashboards.Default.html">
                                        <span class="label">Default</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="Dashboards.Visual.html">
                                        <span class="label">Visual</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="Dashboards.Analytic.html">
                                        <span class="label">Analytic</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#apps" data-href="Apps.html">
                                <i data-cs-icon="screen" class="icon" data-cs-size="18"></i>
                                <span class="label">Apps</span>
                            </a>
                            <ul id="apps">
                                <li>
                                    <a href="Apps.Calendar.html">
                                        <span class="label">Calendar</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="Apps.Chat.html">
                                        <span class="label">Chat</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="Apps.Contacts.html">
                                        <span class="label">Contacts</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="Apps.Mailbox.html">
                                        <span class="label">Mailbox</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="Apps.Tasks.html">
                                        <span class="label">Tasks</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#pages" data-href="Pages.html">
                                <i data-cs-icon="notebook-1" class="icon" data-cs-size="18"></i>
                                <span class="label">Pages</span>
                            </a>
                            <ul id="pages">
                                <li>
                                    <a href="#authentication" data-href="Pages.Authentication.html">
                                        <span class="label">Authentication</span>
                                    </a>
                                    <ul id="authentication">
                                        <li>
                                            <a href="Pages.Authentication.Login.html">
                                                <span class="label">Login</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Pages.Authentication.Register.html">
                                                <span class="label">Register</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Pages.Authentication.ForgotPassword.html">
                                                <span class="label">Forgot Password</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Pages.Authentication.ResetPassword.html">
                                                <span class="label">Reset Password</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#blog" data-href="Pages.Blog.html">
                                        <span class="label">Blog</span>
                                    </a>
                                    <ul id="blog">
                                        <li>
                                            <a href="Pages.Blog.Home.html">
                                                <span class="label">Home</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Pages.Blog.Grid.html">
                                                <span class="label">Grid</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Pages.Blog.List.html">
                                                <span class="label">List</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Pages.Blog.Detail.html">
                                                <span class="label">Detail</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#miscellaneous" data-href="Pages.Miscellaneous.html">
                                        <span class="label">Miscellaneous</span>
                                    </a>
                                    <ul id="miscellaneous">
                                        <li>
                                            <a href="Pages.Miscellaneous.Faq.html">
                                                <span class="label">Faq</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Pages.Miscellaneous.KnowledgeBase.html">
                                                <span class="label">Knowledge Base</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Pages.Miscellaneous.Error.html">
                                                <span class="label">Error</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Pages.Miscellaneous.ComingSoon.html">
                                                <span class="label">Coming Soon</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Pages.Miscellaneous.Pricing.html">
                                                <span class="label">Pricing</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Pages.Miscellaneous.Search.html">
                                                <span class="label">Search</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Pages.Miscellaneous.Mailing.html">
                                                <span class="label">Mailing</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Pages.Miscellaneous.Empty.html">
                                                <span class="label">Empty</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#portfolio" data-href="Pages.Portfolio.html">
                                        <span class="label">Portfolio</span>
                                    </a>
                                    <ul id="portfolio">
                                        <li>
                                            <a href="Pages.Portfolio.Home.html">
                                                <span class="label">Home</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Pages.Portfolio.Detail.html">
                                                <span class="label">Detail</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#profile" data-href="Pages.Profile.html">
                                        <span class="label">Profile</span>
                                    </a>
                                    <ul id="profile">
                                        <li>
                                            <a href="Pages.Profile.Standard.html">
                                                <span class="label">Standard</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Pages.Profile.Settings.html">
                                                <span class="label">Settings</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#blocks" data-href="Blocks.html">
                                <i data-cs-icon="grid-5" class="icon" data-cs-size="18"></i>
                                <span class="label">Blocks</span>
                            </a>
                            <ul id="blocks">
                                <li>
                                    <a href="Blocks.Images.html">
                                        <span class="label">Images</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="Blocks.List.html">
                                        <span class="label">List</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="Blocks.TabularData.html">
                                        <span class="label">Tabular Data</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="Blocks.Thumbnails.html">
                                        <span class="label">Thumbnails</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="Blocks.Cta.html">
                                        <span class="label">Cta</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="Blocks.Gallery.html">
                                        <span class="label">Gallery</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="Blocks.Stats.html">
                                        <span class="label">Stats</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="Blocks.Steps.html">
                                        <span class="label">Steps</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="Blocks.Details.html">
                                        <span class="label">Details</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="mega">
                            <a href="#interface" data-href="Interface.html">
                                <i data-cs-icon="pocket-knife" class="icon" data-cs-size="18"></i>
                                <span class="label">Interface</span>
                            </a>
                            <ul id="interface">
                                <li>
                                    <a href="#interfaceComponents" data-href="Interface.Components.html">
                                        <span class="label">Components</span>
                                    </a>
                                    <ul id="interfaceComponents">
                                        <li>
                                            <a href="Interface.Components.Accordion.html">
                                                <span class="label">Accordion</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Alerts.html">
                                                <span class="label">Alerts</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Badge.html">
                                                <span class="label">Badge</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Breadcrumb.html">
                                                <span class="label">Breadcrumb</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Buttons.html">
                                                <span class="label">Buttons</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.ButtonGroup.html">
                                                <span class="label">Button Group</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Card.html">
                                                <span class="label">Card</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Close.html">
                                                <span class="label">Close Button</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Collapse.html">
                                                <span class="label">Collapse</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Dropdowns.html">
                                                <span class="label">Dropdowns</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.ListGroup.html">
                                                <span class="label">List Group</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Modal.html">
                                                <span class="label">Modal</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Navs.html">
                                                <span class="label">Navs</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Offcanvas.html">
                                                <span class="label">Offcanvas</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Pagination.html">
                                                <span class="label">Pagination</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Popovers.html">
                                                <span class="label">Popovers</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Progress.html">
                                                <span class="label">Progress</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Spinners.html">
                                                <span class="label">Spinners</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Toasts.html">
                                                <span class="label">Toasts</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Components.Tooltips.html">
                                                <span class="label">Tooltips</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#interfaceForms" data-href="Interface.Forms.html">
                                        <span class="label">Forms</span>
                                    </a>
                                    <ul id="interfaceForms">
                                        <li>
                                            <a href="Interface.Forms.Layouts.html">
                                                <span class="label">Layouts</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Forms.Validation.html">
                                                <span class="label">Validation</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Forms.Wizard.html">
                                                <span class="label">Wizard</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Forms.InputGroup.html">
                                                <span class="label">Input Group</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Forms.InputMask.html">
                                                <span class="label">Input Mask</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Forms.GenericForms.html">
                                                <span class="label">Generic Forms</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#formControls" data-href="Interface.Forms.Controls.html">
                                                <span class="label">Controls</span>
                                            </a>
                                            <ul id="formControls">
                                                <li>
                                                    <a href="Interface.Forms.Controls.Autocomplete.html">
                                                        <span class="label">Autocomplete</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Forms.Controls.CheckboxRadio.html">
                                                        <span class="label">Checkbox-Radio</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Forms.Controls.DatePicker.html">
                                                        <span class="label">Date Picker</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Forms.Controls.Dropzone.html">
                                                        <span class="label">Dropzone</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Forms.Controls.Editor.html">
                                                        <span class="label">Editor</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Forms.Controls.InputSpinner.html">
                                                        <span class="label">Input Spinner</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Forms.Controls.Rating.html">
                                                        <span class="label">Rating</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Forms.Controls.Select2.html">
                                                        <span class="label">Select2</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Forms.Controls.Slider.html">
                                                        <span class="label">Slider</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Forms.Controls.Tags.html">
                                                        <span class="label">Tags</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Forms.Controls.TimePicker.html">
                                                        <span class="label">Time Picker</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#interfacePlugins" data-href="Interface.Plugins.html">
                                        <span class="label">Plugins</span>
                                    </a>
                                    <ul id="interfacePlugins">
                                        <li>
                                            <a href="Interface.Plugins.Carousel.html">
                                                <span class="label">Carousel</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Plugins.Charts.html">
                                                <span class="label">Charts</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Plugins.Clamp.html">
                                                <span class="label">Clamp</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Plugins.ContextMenu.html">
                                                <span class="label">Context Menu</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#pluginsDatatables" data-href="Interface.Plugins.Datatables.html">
                                                <span class="label">Datatables</span>
                                            </a>
                                            <ul id="pluginsDatatables">
                                                <li>
                                                    <a href="Interface.Plugins.Datatables.EditableRows.html">
                                                        <span class="label">Editable Rows</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Plugins.Datatables.EditableBoxed.html">
                                                        <span class="label">Editable Boxed</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Plugins.Datatables.RowsAjax.html">
                                                        <span class="label">Ajax Data</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Plugins.Datatables.RowsServerSide.html">
                                                        <span class="label">Server Side</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Plugins.Datatables.BoxedVariations.html">
                                                        <span class="label">Boxed Variations</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="Interface.Plugins.Lightbox.html">
                                                <span class="label">Lightbox</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Plugins.List.html">
                                                <span class="label">List</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Plugins.Maps.html">
                                                <span class="label">Maps</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Plugins.Notify.html">
                                                <span class="label">Notify</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Plugins.Player.html">
                                                <span class="label">Players</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Plugins.Progress.html">
                                                <span class="label">Progress</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Plugins.Scrollbar.html">
                                                <span class="label">Scrollbar</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Plugins.Shortcuts.html">
                                                <span class="label">Shortcuts</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Plugins.Sortable.html">
                                                <span class="label">Sortable</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#interfaceContent" data-href="Interface.Content.html">
                                        <span class="label">Content</span>
                                    </a>
                                    <ul id="interfaceContent">
                                        <li>
                                            <a href="#icons" data-href="Interface.Content.Icons.html">
                                                <span class="label">Icons</span>
                                            </a>
                                            <ul id="icons">
                                                <li>
                                                    <a href="Interface.Content.Icons.CSLineIcons.html">
                                                        <span class="label">CS Line Icons</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Content.Icons.CSLineInterfaceIcons.html">
                                                        <span class="label">CS Interface Icons</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Content.Icons.BootstrapIcons.html">
                                                        <span class="label">Bootstrap Icons</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="Interface.Content.Images.html">
                                                <span class="label">Images</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Content.Tables.html">
                                                <span class="label">Tables</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="Interface.Content.Typography.html">
                                                <span class="label">Typography</span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#menuVarieties" data-href="Interface.Content.Menu.html">
                                                <span class="label">Menu</span>
                                            </a>
                                            <ul id="menuVarieties">
                                                <li>
                                                    <a href="Interface.Content.Menu.HorizontalStandard.html">
                                                        <span class="label">Horizontal</span>
                                                    </a>
                                                </li>
                                                <li></li>
                                                <li>
                                                    <a href="Interface.Content.Menu.VerticalStandard.html">
                                                        <span class="label">Vertical</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Content.Menu.VerticalSemiHidden.html">
                                                        <span class="label">Vertical Hidden</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Content.Menu.VerticalNoSemiHidden.html">
                                                        <span class="label">Vertical No Hidden</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Content.Menu.MobileOnly.html">
                                                        <span class="label">Mobile Only</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="Interface.Content.Menu.Sidebar.html">
                                                        <span class="label">Sidebar</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <!-- Menu End -->

                <!-- Mobile Buttons Start -->
                <div class="mobile-buttons-container">
                    <!-- Scrollspy Mobile Button Start -->
                    <a href="#" id="scrollSpyButton" class="spy-button" data-bs-toggle="dropdown">
                        <i data-cs-icon="menu-dropdown"></i>
                    </a>
                    <!-- Scrollspy Mobile Button End -->

                    <!-- Scrollspy Mobile Dropdown Start -->
                    <div class="dropdown-menu dropdown-menu-end" id="scrollSpyDropdown"></div>
                    <!-- Scrollspy Mobile Dropdown End -->

                    <!-- Menu Button Start -->
                    <a href="#" id="mobileMenuButton" class="menu-button">
                        <i data-cs-icon="menu"></i>
                    </a>
                    <!-- Menu Button End -->
                </div>
                <!-- Mobile Buttons End -->
            </div>
            <div class="nav-shadow"></div>
        </div>

        <main>
            <div class="container">
                <!-- Title and Top Buttons Start -->
                <div class="page-title-container">
                    <div class="row">
                        <!-- Title Start -->
                        <div class="col-12 col-md-7">
                            <h1 class="mb-0 pb-0 display-4" id="title">Portfolio Home</h1>
                            <nav class="breadcrumb-container d-inline-block" aria-label="breadcrumb">
                                <ul class="breadcrumb pt-0">
                                    <li class="breadcrumb-item"><a href="Dashboards.Default.html">Home</a></li>
                                    <li class="breadcrumb-item"><a href="Pages.html">Pages</a></li>
                                    <li class="breadcrumb-item"><a href="Pages.Portfolio.html">Portfolio</a></li>
                                </ul>
                            </nav>
                        </div>
                        <!-- Title End -->

                        <!-- Top Buttons Start -->
                        <div class="col-12 col-md-5 d-flex align-items-start justify-content-end">
                            <!-- Contact Button Start -->
                            <button type="button" class="btn btn-outline-primary btn-icon btn-icon-start w-100 w-md-auto">
                                <i data-cs-icon="email"></i>
                                <span>Contact</span>
                            </button>
                            <!-- Contact Button End -->

                            <!-- Dropdown Button Start -->
                            <div class="ms-1">
                                <button type="button" class="btn btn-outline-primary btn-icon btn-icon-only" data-bs-offset="0,3" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-submenu>
                                    <i data-cs-icon="more-horizontal"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <button class="dropdown-item" type="button">Follow</button>
                                    <button class="dropdown-item" type="button">Hire</button>
                                    <button class="dropdown-item" type="button">Report</button>
                                </div>
                            </div>
                            <!-- Dropdown Button End -->
                        </div>
                        <!-- Top Buttons End -->
                    </div>
                </div>
                <!-- Title and Top Buttons End -->

                <div class="row gx-4 gy-5">
                    <!-- Left Side Start -->
                    <div class="col-12 col-xl-4 col-xxl-3">
                        <!-- Biography Start -->
                        <h2 class="small-title">Biography</h2>
                        <div class="card">
                            <div class="card-body mb-n5">
                                <div class="d-flex align-items-center flex-column mb-5">
                                    <div class="mb-5 d-flex align-items-center flex-column">
                                        <div class="sw-13 position-relative mb-3">
                                            <img src="img/profile/profile-2.jpg" class="img-fluid rounded-xl" alt="thumb" />
                                        </div>
                                        <div class="h5 mb-0">Blaine Cottrell</div>
                                        <div class="text-muted">Executive UI/UX Designer</div>
                                        <div class="text-muted">
                                            <i data-cs-icon="pin" class="me-1"></i>
                                            <span class="align-middle">Montreal, Canada</span>
                                        </div>
                                    </div>
                                    <div class="d-flex flex-row justify-content-between w-100 w-sm-50 w-xl-100">
                                        <button type="button" class="btn btn-primary w-100 me-2">Hire</button>
                                        <button type="button" class="btn btn-outline-primary w-100 me-2">Follow</button>
                                        <button class="btn btn-icon btn-icon-only btn-outline-primary" type="button">
                                            <i data-cs-icon="more-horizontal"></i>
                                        </button>
                                    </div>
                                </div>

                                <div class="mb-5">
                                    <div class="row g-0 align-items-center mb-2">
                                        <div class="col-auto">
                                            <div class="border border-primary sw-5 sh-5 rounded-xl d-flex justify-content-center align-items-center">
                                                <i data-cs-icon="screen" class="text-primary"></i>
                                            </div>
                                        </div>
                                        <div class="col ps-3">
                                            <div class="row g-0">
                                                <div class="col">
                                                    <div class="sh-5 d-flex align-items-center lh-1-25">Project Views</div>
                                                </div>
                                                <div class="col-auto">
                                                    <div class="sh-5 d-flex align-items-center">23.573</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row g-0 align-items-center mb-2">
                                        <div class="col-auto">
                                            <div class="border border-primary sw-5 sh-5 rounded-xl d-flex justify-content-center align-items-center">
                                                <i data-cs-icon="paint-roller" class="text-primary"></i>
                                            </div>
                                        </div>
                                        <div class="col ps-3">
                                            <div class="row g-0">
                                                <div class="col">
                                                    <div class="sh-5 d-flex align-items-center lh-1-25">Project Saves</div>
                                                </div>
                                                <div class="col-auto">
                                                    <div class="sh-5 d-flex align-items-center">1.124</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row g-0 align-items-center mb-2">
                                        <div class="col-auto">
                                            <div class="border border-primary sw-5 sh-5 rounded-xl d-flex justify-content-center align-items-center">
                                                <i data-cs-icon="like" class="text-primary"></i>
                                            </div>
                                        </div>
                                        <div class="col ps-3">
                                            <div class="row g-0">
                                                <div class="col">
                                                    <div class="sh-5 d-flex align-items-center lh-1-25">Likes</div>
                                                </div>
                                                <div class="col-auto">
                                                    <div class="sh-5 d-flex align-items-center">12.573</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row g-0 align-items-center mb-2">
                                        <div class="col-auto">
                                            <div class="border border-primary sw-5 sh-5 rounded-xl d-flex justify-content-center align-items-center">
                                                <i data-cs-icon="user" class="text-primary"></i>
                                            </div>
                                        </div>
                                        <div class="col ps-3">
                                            <div class="row g-0">
                                                <div class="col">
                                                    <div class="sh-5 d-flex align-items-center lh-1-25">Followers</div>
                                                </div>
                                                <div class="col-auto">
                                                    <div class="sh-5 d-flex align-items-center">1.245</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-5">
                                    <p class="text-small text-muted mb-2">ABOUT ME</p>
                                    <p>
                                        Jujubes brownie marshmallow apple pie donut ice cream jelly-o jelly-o gummi bears. Tootsie roll chocolate bar dragée bonbon cheesecake
                                        icing. Danish wafer donut cookie caramels gummies topping.
                                    </p>
                                </div>
                                <div class="mb-5">
                                    <p class="text-small text-muted mb-2">INTERESTS</p>
                                    <p>
                                        Chocolate cake biscuit donut cotton candy soufflé cake macaroon. Halvah chocolate cotton candy sweet roll jelly-o candy danish dragée.
                                        Apple pie cotton candy tiramisu biscuit cake muffin tootsie roll bear claw cake. Cupcake cake fruitcake.
                                    </p>
                                </div>
                                <div class="mb-5">
                                    <p class="text-small text-muted mb-2">CONTACT</p>
                                    <a href="#" class="d-block body-link mb-1">
                                        <i data-cs-icon="screen" class="me-2" data-cs-size="17"></i>
                                        <span class="align-middle">blainecottrell.com</span>
                                    </a>
                                    <a href="#" class="d-block body-link">
                                        <i data-cs-icon="email" class="me-2" data-cs-size="17"></i>
                                        <span class="align-middle">contact@blainecottrell.com</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <!-- Biography End -->
                    </div>
                    <!-- Left Side End -->

                    <!-- Right Side Start -->
                    <div class="col-12 col-xl-8 col-xxl-9">
                        <!-- Title Tabs Start -->
                        <ul class="nav nav-tabs nav-tabs-title nav-tabs-line-title responsive-tabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <a class="nav-link active" data-bs-toggle="tab" href="#projectsTab" role="tab" aria-selected="true">Projects</a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" data-bs-toggle="tab" href="#collectionsTab" role="tab" aria-selected="false">Collections</a>
                            </li>
                            <li class="nav-item" role="presentation">
                                <a class="nav-link" data-bs-toggle="tab" href="#friendsTab" role="tab" aria-selected="false">Friends</a>
                            </li>
                            <li class="nav-item dropdown ms-auto d-none responsive-tab-dropdown">
                                <a class="btn btn-icon btn-icon-only btn-background pt-0" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-diplay="static">
                                    <i data-cs-icon="more-horizontal"></i>
                                </a>
                                <ul class="dropdown-menu mt-2 dropdown-menu-end"></ul>
                            </li>
                        </ul>
                        <!-- Title Tabs End -->

                        <div class="tab-content">
                            <!-- Projects Tab Start -->
                            <div class="tab-pane fade active show" id="projectsTab" role="tabpanel">
                                <div class="row row-cols-1 row-cols-sm-2 row-cols-xxl-3 g-2 mb-5">
                                    <div class="col">
                                        <div class="card sh-35 hover-img-scale-up hover-reveal">
                                            <img src="img/product/small/cornbread.jpg" class="card-img h-100 scale" alt="card image" />
                                            <div class="card-img-overlay d-flex flex-column justify-content-between reveal-content">
                                                <div class="row g-0">
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="eye" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">153</span>
                                                    </div>
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="message" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">5</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <i data-cs-icon="like" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">29</span>
                                                    </div>
                                                </div>
                                                <div class="row g-0">
                                                    <div class="col pe-2">
                                                        <a href="Pages.Portfolio.Detail.html" class="stretched-link">
                                                            <h5 class="heading text-white mb-1">Introduction to Bread Making</h5>
                                                        </a>
                                                        <div class="d-inline-block">
                                                            <div class="text-white">Blaine Cottrell</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-auto me-auto">
                                                        <button class="btn btn-icon btn-icon-only btn-foreground mb-1" type="button">
                                                            <i data-cs-icon="like"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card sh-35 hover-img-scale-up hover-reveal">
                                            <img src="img/product/small/zopf.jpg" class="card-img h-100 scale" alt="card image" />
                                            <div class="card-img-overlay d-flex flex-column justify-content-between reveal-content">
                                                <div class="row g-0">
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="eye" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">224</span>
                                                    </div>
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="message" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">2</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <i data-cs-icon="like" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">52</span>
                                                    </div>
                                                </div>
                                                <div class="row g-0">
                                                    <div class="col pe-2">
                                                        <a href="Pages.Portfolio.Detail.html" class="stretched-link">
                                                            <h5 class="heading text-white mb-1">14 Facts About Sugar Products</h5>
                                                        </a>
                                                        <div class="d-inline-block">
                                                            <div class="text-white">Cherish Kerr</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-auto me-auto">
                                                        <button class="btn btn-icon btn-icon-only btn-foreground mb-1" type="button">
                                                            <i data-cs-icon="like"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card sh-35 hover-img-scale-up hover-reveal">
                                            <img src="img/product/small/pain-de-campagne.jpg" class="card-img h-100 scale" alt="card image" />
                                            <div class="card-img-overlay d-flex flex-column justify-content-between reveal-content">
                                                <div class="row g-0">
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="eye" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">13</span>
                                                    </div>
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="message" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">5</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <i data-cs-icon="like" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">12</span>
                                                    </div>
                                                </div>
                                                <div class="row g-0">
                                                    <div class="col pe-2">
                                                        <a href="Pages.Portfolio.Detail.html" class="stretched-link">
                                                            <h5 class="heading text-white mb-1">Apple Cake Recipe</h5>
                                                        </a>
                                                        <div class="d-inline-block">
                                                            <div class="text-white">Kirby Peters</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-auto me-auto">
                                                        <button class="btn btn-icon btn-icon-only btn-foreground mb-1" type="button">
                                                            <i data-cs-icon="like"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card sh-35 hover-img-scale-up hover-reveal">
                                            <img src="img/product/small/rugbraud.jpg" class="card-img h-100 scale" alt="card image" />
                                            <div class="card-img-overlay d-flex flex-column justify-content-between reveal-content">
                                                <div class="row g-0">
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="eye" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">155</span>
                                                    </div>
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="message" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">6</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <i data-cs-icon="like" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">46</span>
                                                    </div>
                                                </div>
                                                <div class="row g-0">
                                                    <div class="col pe-2">
                                                        <a href="Pages.Portfolio.Detail.html" class="stretched-link">
                                                            <h5 class="heading text-white mb-1">Complete Guide to Mix Dough</h5>
                                                        </a>
                                                        <div class="d-inline-block">
                                                            <div class="text-white">Olli Hawkins</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-auto me-auto">
                                                        <button class="btn btn-icon btn-icon-only btn-foreground mb-1" type="button">
                                                            <i data-cs-icon="like"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card sh-35 hover-img-scale-up hover-reveal">
                                            <img src="img/product/small/steirer-brot.jpg" class="card-img h-100 scale" alt="card image" />
                                            <div class="card-img-overlay d-flex flex-column justify-content-between reveal-content">
                                                <div class="row g-0">
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="eye" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">82</span>
                                                    </div>
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="message" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">4</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <i data-cs-icon="like" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">3</span>
                                                    </div>
                                                </div>
                                                <div class="row g-0">
                                                    <div class="col pe-2">
                                                        <a href="Pages.Portfolio.Detail.html" class="stretched-link">
                                                            <h5 class="heading text-white mb-1">10 Secrets Every Southern Baker Knows</h5>
                                                        </a>
                                                        <div class="d-inline-block">
                                                            <div class="text-white">Kathryn Mengel</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-auto me-auto">
                                                        <button class="btn btn-icon btn-icon-only btn-foreground mb-1" type="button">
                                                            <i data-cs-icon="like"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card sh-35 hover-img-scale-up hover-reveal">
                                            <img src="img/product/small/panettone.jpg" class="card-img h-100 scale" alt="card image" />
                                            <div class="card-img-overlay d-flex flex-column justify-content-between reveal-content">
                                                <div class="row g-0">
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="eye" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">55</span>
                                                    </div>
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="message" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">1</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <i data-cs-icon="like" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">4</span>
                                                    </div>
                                                </div>
                                                <div class="row g-0">
                                                    <div class="col pe-2">
                                                        <a href="Pages.Portfolio.Detail.html" class="stretched-link">
                                                            <h5 class="heading text-white mb-1">Recipes for Sweet and Healty Treats</h5>
                                                        </a>
                                                        <div class="d-inline-block">
                                                            <div class="text-white">Esperanza Lodge</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-auto me-auto">
                                                        <button class="btn btn-icon btn-icon-only btn-foreground mb-1" type="button">
                                                            <i data-cs-icon="like"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card sh-35 hover-img-scale-up hover-reveal">
                                            <img src="img/product/small/pullman-loaf.jpg" class="card-img h-100 scale" alt="card image" />
                                            <div class="card-img-overlay d-flex flex-column justify-content-between reveal-content">
                                                <div class="row g-0">
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="eye" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">49</span>
                                                    </div>
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="message" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">19</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <i data-cs-icon="like" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">8</span>
                                                    </div>
                                                </div>
                                                <div class="row g-0">
                                                    <div class="col pe-2">
                                                        <a href="Pages.Portfolio.Detail.html" class="stretched-link">
                                                            <h5 class="heading text-white mb-1">Mix Dough for the Molds</h5>
                                                        </a>
                                                        <div class="d-inline-block">
                                                            <div class="text-white">Zayn Hartley</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-auto me-auto">
                                                        <button class="btn btn-icon btn-icon-only btn-foreground mb-1" type="button">
                                                            <i data-cs-icon="like"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card sh-35 hover-img-scale-up hover-reveal">
                                            <img src="img/product/small/michetta.jpg" class="card-img h-100 scale" alt="card image" />
                                            <div class="card-img-overlay d-flex flex-column justify-content-between reveal-content">
                                                <div class="row g-0">
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="eye" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">81</span>
                                                    </div>
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="message" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">13</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <i data-cs-icon="like" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">5</span>
                                                    </div>
                                                </div>
                                                <div class="row g-0">
                                                    <div class="col pe-2">
                                                        <a href="Pages.Portfolio.Detail.html" class="stretched-link">
                                                            <h5 class="heading text-white mb-1">Basic Introduction for Dough Molding</h5>
                                                        </a>
                                                        <div class="d-inline-block">
                                                            <div class="text-white">Joisse Kaycee</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-auto me-auto">
                                                        <button class="btn btn-icon btn-icon-only btn-foreground mb-1" type="button">
                                                            <i data-cs-icon="like"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card sh-35 hover-img-scale-up hover-reveal">
                                            <img src="img/product/small/sandwich-bread.jpg" class="card-img h-100 scale" alt="card image" />
                                            <div class="card-img-overlay d-flex flex-column justify-content-between reveal-content">
                                                <div class="row g-0">
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="eye" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">64</span>
                                                    </div>
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="message" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">9</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <i data-cs-icon="like" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">3</span>
                                                    </div>
                                                </div>
                                                <div class="row g-0">
                                                    <div class="col pe-2">
                                                        <a href="Pages.Portfolio.Detail.html" class="stretched-link">
                                                            <h5 class="heading text-white mb-1">Mix Dough for the Molds</h5>
                                                        </a>
                                                        <div class="d-inline-block">
                                                            <div class="text-white">Kirby Peters</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-auto me-auto">
                                                        <button class="btn btn-icon btn-icon-only btn-foreground mb-1" type="button">
                                                            <i data-cs-icon="like"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card sh-35 hover-img-scale-up hover-reveal">
                                            <img src="img/product/small/hamburger-bun.jpg" class="card-img h-100 scale" alt="card image" />
                                            <div class="card-img-overlay d-flex flex-column justify-content-between reveal-content">
                                                <div class="row g-0">
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="eye" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">35</span>
                                                    </div>
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="message" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">2</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <i data-cs-icon="like" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">5</span>
                                                    </div>
                                                </div>
                                                <div class="row g-0">
                                                    <div class="col pe-2">
                                                        <a href="Pages.Portfolio.Detail.html" class="stretched-link">
                                                            <h5 class="heading text-white mb-1">Introduction to Baking Donut</h5>
                                                        </a>
                                                        <div class="d-inline-block">
                                                            <div class="text-white">Peter Linatti</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-auto me-auto">
                                                        <button class="btn btn-icon btn-icon-only btn-foreground mb-1" type="button">
                                                            <i data-cs-icon="like"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card sh-35 hover-img-scale-up hover-reveal">
                                            <img src="img/product/small/boule.jpg" class="card-img h-100 scale" alt="card image" />
                                            <div class="card-img-overlay d-flex flex-column justify-content-between reveal-content">
                                                <div class="row g-0">
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="eye" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">27</span>
                                                    </div>
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="message" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">12</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <i data-cs-icon="like" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">8</span>
                                                    </div>
                                                </div>
                                                <div class="row g-0">
                                                    <div class="col pe-2">
                                                        <a href="Pages.Portfolio.Detail.html" class="stretched-link">
                                                            <h5 class="heading text-white mb-1">Apple Cake Recipe for Starters</h5>
                                                        </a>
                                                        <div class="d-inline-block">
                                                            <div class="text-white">Rosa Holt</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-auto me-auto">
                                                        <button class="btn btn-icon btn-icon-only btn-foreground mb-1" type="button">
                                                            <i data-cs-icon="like"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card sh-35 hover-img-scale-up hover-reveal">
                                            <img src="img/product/small/barmbrack.jpg" class="card-img h-100 scale" alt="card image" />
                                            <div class="card-img-overlay d-flex flex-column justify-content-between reveal-content">
                                                <div class="row g-0">
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="eye" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">15</span>
                                                    </div>
                                                    <div class="col-auto pe-3">
                                                        <i data-cs-icon="message" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">2</span>
                                                    </div>
                                                    <div class="col-auto">
                                                        <i data-cs-icon="like" class="text-white me-1" data-cs-size="15"></i>
                                                        <span class="align-middle text-white">0</span>
                                                    </div>
                                                </div>
                                                <div class="row g-0">
                                                    <div class="col pe-2">
                                                        <a href="Pages.Portfolio.Detail.html" class="stretched-link">
                                                            <h5 class="heading text-white mb-1">6 Facts About Sugar Products</h5>
                                                        </a>
                                                        <div class="d-inline-block">
                                                            <div class="text-white">Josh Henderson</div>
                                                        </div>
                                                    </div>
                                                    <div class="col-auto me-auto">
                                                        <button class="btn btn-icon btn-icon-only btn-foreground mb-1" type="button">
                                                            <i data-cs-icon="like"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <button class="btn btn-xl btn-outline-primary sw-30">Load More</button>
                                </div>
                            </div>
                            <!-- Projects Tab End -->

                            <!-- Collections Tab Start -->
                            <div class="tab-pane fade" id="collectionsTab" role="tabpanel">
                                <div class="row row-cols-1 row-cols-sm-2 row-cols-xxl-3 g-2">
                                    <div class="col-12 col-sm-6 col-lg-6 col-xxl-6">
                                        <div class="card">
                                            <div class="sh-35">
                                                <div class="row g-1 h-100 gallery">
                                                    <div class="col h-100">
                                                        <a href="img/product/large/steirer-brot.jpg" class="w-100 h-100 rounded-xl-top-start bg-cover-center d-block" style="background-image: url(img/product/small/steirer-brot.jpg)"></a>
                                                    </div>
                                                    <div class="col d-flex flex-column justify-content-stretch h-100">
                                                        <div class="d-flex mb-1 flex-grow-1">
                                                            <a href="img/product/large/buccellato-di-lucca.jpg" class="w-100 h-100 rounded-xl-top-end bg-cover-center d-block" style="background-image: url(img/product/small/buccellato-di-lucca.jpg)"></a>
                                                        </div>
                                                        <div class="d-flex flex-grow-1">
                                                            <a href="img/product/large/rugbraud.jpg" class="w-100 h-100 bg-cover-center d-block" style="background-image: url(img/product/small/rugbraud.jpg)"></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <h5 class="heading mb-0">
                                                    <a href="#" class="body-link sh-5 d-inline-block">
                                                        <span class="clamp-line" data-line="2">Apple Cake Recipe for Starters</span>
                                                    </a>
                                                </h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-6 col-lg-6 col-xxl-6">
                                        <div class="card">
                                            <div class="sh-35">
                                                <div class="row g-1 h-100 gallery">
                                                    <div class="col d-flex flex-column justify-content-stretch h-100">
                                                        <div class="d-flex mb-1 flex-grow-1">
                                                            <a href="img/product/large/bauernbrot.jpg" class="w-100 h-100 rounded-xl-top bg-cover-center d-block" style="background-image: url(img/product/small/bauernbrot.jpg)"></a>
                                                        </div>
                                                        <div class="d-flex flex-grow-1">
                                                            <a href="img/product/large/zopf.jpg" class="w-100 h-100 bg-cover-center d-block" style="background-image: url(img/product/small/zopf.jpg)"></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <h5 class="heading mb-0">
                                                    <a href="#" class="body-link sh-5 d-inline-block">
                                                        <span class="clamp-line" data-line="2">Basic Introduction for Dough Molding</span>
                                                    </a>
                                                </h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-6 col-lg-6 col-xxl-6">
                                        <div class="card">
                                            <div class="sh-35">
                                                <div class="row g-1 h-100 gallery">
                                                    <div class="col h-100">
                                                        <a href="img/product/large/panettone.jpg" class="w-100 h-100 rounded-xl-top-start bg-cover-center d-block" style="background-image: url(img/product/small/panettone.jpg)"></a>
                                                    </div>
                                                    <div class="col h-100">
                                                        <a href="img/product/large/cornbread.jpg" class="w-100 h-100 rounded-xl-top-end bg-cover-center d-block" style="background-image: url(img/product/small/cornbread.jpg)"></a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <h5 class="heading mb-0">
                                                    <a href="#" class="body-link sh-5 d-inline-block">
                                                        <span class="clamp-line" data-line="2">Recipes for Sweet and Healty Treats</span>
                                                    </a>
                                                </h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-6 col-lg-6 col-xxl-6">
                                        <div class="card">
                                            <div class="sh-35">
                                                <div class="row g-1 h-100 gallery">
                                                    <div class="col d-flex flex-column justify-content-stretch h-100">
                                                        <div class="d-flex mb-1 flex-grow-1">
                                                            <a href="img/product/large/baguette.jpg" class="w-100 h-100 rounded-xl-top-start bg-cover-center d-block" style="background-image: url(img/product/small/baguette.jpg)"></a>
                                                        </div>
                                                        <div class="d-flex flex-grow-1">
                                                            <a href="img/product/large/rugbraud.jpg" class="w-100 h-100 bg-cover-center d-block" style="background-image: url(img/product/small/rugbraud.jpg)"></a>
                                                        </div>
                                                    </div>
                                                    <div class="col d-flex flex-column justify-content-stretch h-100">
                                                        <div class="d-flex mb-1 flex-grow-1">
                                                            <a href="img/product/large/guernsey-gache.jpg" class="w-100 h-100 rounded-xl-top-end bg-cover-center d-block" style="background-image: url(img/product/small/guernsey-gache.jpg)"></a>
                                                        </div>
                                                        <div class="d-flex flex-grow-1">
                                                            <a href="img/product/large/pain-de-campagne.jpg" class="w-100 h-100 bg-cover-center d-block" style="background-image: url(img/product/small/pain-de-campagne.jpg)"></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <h5 class="heading mb-0">
                                                    <a href="#" class="body-link sh-5 d-inline-block">
                                                        <span class="clamp-line" data-line="2">10 Secrets Every Southern Baker Knows</span>
                                                    </a>
                                                </h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12 col-sm-6 col-lg-6 col-xxl-6">
                                        <div class="card">
                                            <div class="sh-35">
                                                <div class="row g-1 h-100 gallery">
                                                    <div class="col d-flex flex-column justify-content-stretch h-100">
                                                        <div class="d-flex mb-1 flex-grow-1">
                                                            <a href="img/product/large/buccellato-di-lucca.jpg" class="w-100 h-100 rounded-xl-top bg-cover-center d-block" style="background-image: url(img/product/small/buccellato-di-lucca.jpg)"></a>
                                                        </div>
                                                        <div class="d-flex flex-grow-1">
                                                            <a href="img/product/large/rugbraud.jpg" class="w-100 h-100 bg-cover-center d-block" style="background-image: url(img/product/small/rugbraud.jpg)"></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body">
                                                <h5 class="heading mb-0">
                                                    <a href="#" class="body-link sh-5 d-inline-block">
                                                        <span class="clamp-line" data-line="2">Basic Introduction to Cornbread Making</span>
                                                    </a>
                                                </h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Collections Tab End -->

                            <!-- Friends Tab Start -->
                            <div class="tab-pane fade" id="friendsTab" role="tabpanel">
                                <div class="row row-cols-1 row-cols-md-2 row-cols-xxl-3 g-2">
                                    <div class="col">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="row g-0 sh-6">
                                                    <div class="col-auto">
                                                        <img src="img/profile/profile-1.jpg" class="card-img rounded-xl sh-6 sw-6" alt="thumb" />
                                                    </div>
                                                    <div class="col">
                                                        <div class="card-body d-flex flex-row pt-0 pb-0 ps-3 pe-0 h-100 align-items-center justify-content-between">
                                                            <div class="d-flex flex-column">
                                                                <div>Blaine Cottrell</div>
                                                                <div class="text-small text-muted">Project Manager</div>
                                                            </div>
                                                            <div class="d-flex">
                                                                <button type="button" class="btn btn-outline-primary btn-sm ms-1">Follow</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="row g-0 sh-6">
                                                    <div class="col-auto">
                                                        <img src="img/profile/profile-4.jpg" class="card-img rounded-xl sh-6 sw-6" alt="thumb" />
                                                    </div>
                                                    <div class="col">
                                                        <div class="card-body d-flex flex-row pt-0 pb-0 ps-3 pe-0 h-100 align-items-center justify-content-between">
                                                            <div class="d-flex flex-column">
                                                                <div>Cherish Kerr</div>
                                                                <div class="text-small text-muted">Development Lead</div>
                                                            </div>
                                                            <div class="d-flex">
                                                                <button type="button" class="btn btn-outline-primary btn-sm ms-1">Follow</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="row g-0 sh-6">
                                                    <div class="col-auto">
                                                        <img src="img/profile/profile-8.jpg" class="card-img rounded-xl sh-6 sw-6" alt="thumb" />
                                                    </div>
                                                    <div class="col">
                                                        <div class="card-body d-flex flex-row pt-0 pb-0 ps-3 pe-0 h-100 align-items-center justify-content-between">
                                                            <div class="d-flex flex-column">
                                                                <div>Kirby Peters</div>
                                                                <div class="text-small text-muted">Accounting</div>
                                                            </div>
                                                            <div class="d-flex">
                                                                <button type="button" class="btn btn-outline-primary btn-sm ms-1">Follow</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="row g-0 sh-6">
                                                    <div class="col-auto">
                                                        <img src="img/profile/profile-5.jpg" class="card-img rounded-xl sh-6 sw-6" alt="thumb" />
                                                    </div>
                                                    <div class="col">
                                                        <div class="card-body d-flex flex-row pt-0 pb-0 ps-3 pe-0 h-100 align-items-center justify-content-between">
                                                            <div class="d-flex flex-column">
                                                                <div>Olli Hawkins</div>
                                                                <div class="text-small text-muted">Client Relations Lead</div>
                                                            </div>
                                                            <div class="d-flex">
                                                                <button type="button" class="btn btn-outline-primary btn-sm ms-1">Follow</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="row g-0 sh-6">
                                                    <div class="col-auto">
                                                        <img src="img/profile/profile-2.jpg" class="card-img rounded-xl sh-6 sw-6" alt="thumb" />
                                                    </div>
                                                    <div class="col">
                                                        <div class="card-body d-flex flex-row pt-0 pb-0 ps-3 pe-0 h-100 align-items-center justify-content-between">
                                                            <div class="d-flex flex-column">
                                                                <div>Zayn Hartley</div>
                                                                <div class="text-small text-muted">Customer Engagement</div>
                                                            </div>
                                                            <div class="d-flex">
                                                                <button type="button" class="btn btn-outline-primary btn-sm ms-1">Follow</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="row g-0 sh-6">
                                                    <div class="col-auto">
                                                        <img src="img/profile/profile-3.jpg" class="card-img rounded-xl sh-6 sw-6" alt="thumb" />
                                                    </div>
                                                    <div class="col">
                                                        <div class="card-body d-flex flex-row pt-0 pb-0 ps-3 pe-0 h-100 align-items-center justify-content-between">
                                                            <div class="d-flex flex-column">
                                                                <div>Esperanza Lodge</div>
                                                                <div class="text-small text-muted">UX Designer</div>
                                                            </div>
                                                            <div class="d-flex">
                                                                <button type="button" class="btn btn-outline-primary btn-sm ms-1">Follow</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="row g-0 sh-6">
                                                    <div class="col-auto">
                                                        <img src="img/profile/profile-4.jpg" class="card-img rounded-xl sh-6 sw-6" alt="thumb" />
                                                    </div>
                                                    <div class="col">
                                                        <div class="card-body d-flex flex-row pt-0 pb-0 ps-3 pe-0 h-100 align-items-center justify-content-between">
                                                            <div class="d-flex flex-column">
                                                                <div>Kerr Jackson</div>
                                                                <div class="text-small text-muted">Frontend Developer</div>
                                                            </div>
                                                            <div class="d-flex">
                                                                <button type="button" class="btn btn-outline-primary btn-sm ms-1">Follow</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="row g-0 sh-6">
                                                    <div class="col-auto">
                                                        <img src="img/profile/profile-6.jpg" class="card-img rounded-xl sh-6 sw-6" alt="thumb" />
                                                    </div>
                                                    <div class="col">
                                                        <div class="card-body d-flex flex-row pt-0 pb-0 ps-3 pe-0 h-100 align-items-center justify-content-between">
                                                            <div class="d-flex flex-column">
                                                                <div>Kathryn Mengel</div>
                                                                <div class="text-small text-muted">Team Leader</div>
                                                            </div>
                                                            <div class="d-flex">
                                                                <button type="button" class="btn btn-outline-primary btn-sm ms-1">Follow</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="row g-0 sh-6">
                                                    <div class="col-auto">
                                                        <img src="img/profile/profile-6.jpg" class="card-img rounded-xl sh-6 sw-6" alt="thumb" />
                                                    </div>
                                                    <div class="col">
                                                        <div class="card-body d-flex flex-row pt-0 pb-0 ps-3 pe-0 h-100 align-items-center justify-content-between">
                                                            <div class="d-flex flex-column">
                                                                <div>Joisse Kaycee</div>
                                                                <div class="text-small text-muted">Copywriter</div>
                                                            </div>
                                                            <div class="d-flex">
                                                                <button type="button" class="btn btn-outline-primary btn-sm ms-1">Follow</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="row g-0 sh-6">
                                                    <div class="col-auto">
                                                        <img src="img/profile/profile-7.jpg" class="card-img rounded-xl sh-6 sw-6" alt="thumb" />
                                                    </div>
                                                    <div class="col">
                                                        <div class="card-body d-flex flex-row pt-0 pb-0 ps-3 pe-0 h-100 align-items-center justify-content-between">
                                                            <div class="d-flex flex-column">
                                                                <div>Zayn Hartley</div>
                                                                <div class="text-small text-muted">Visual Effect Designer</div>
                                                            </div>
                                                            <div class="d-flex">
                                                                <button type="button" class="btn btn-outline-primary btn-sm ms-1">Follow</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Friends Tab End -->
                        </div>
                    </div>
                    <!-- Right Side End -->
                </div>
            </div>
        </main>

        <!-- Layout Footer Start -->
        <footer>
            <div class="footer-content">
                <div class="container">
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <p class="mb-0 text-muted text-medium">Colored Strategies 2021</p>
                        </div>
                        <div class="col-sm-6 d-none d-sm-block">
                            <ul class="breadcrumb pt-0 pe-0 mb-0 float-end">
                                <li class="breadcrumb-item mb-0 text-medium">
                                    <a href="https://1.envato.market/BX5oGy" target="_blank" class="btn-link">Review</a>
                                </li>
                                <li class="breadcrumb-item mb-0 text-medium">
                                    <a href="https://1.envato.market/BX5oGy" target="_blank" class="btn-link">Purchase</a>
                                </li>
                                <li class="breadcrumb-item mb-0 text-medium">
                                    <a href="https://acorn-html-docs.coloredstrategies.com/" target="_blank" class="btn-link">Docs</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Layout Footer End -->
    </div>

    <!-- Theme Settings Modal Start -->
    <div class="modal fade modal-right scroll-out-negative" id="settings" data-bs-backdrop="true" tabindex="-1" role="dialog" aria-labelledby="settings" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable full" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Theme Settings</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="scroll-track-visible">
                        <div class="mb-5" id="color">
                            <label class="mb-3 d-inline-block form-label">Color</label>
                            <div class="row d-flex g-3 justify-content-between flex-wrap mb-3">
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="light-blue" data-parent="color">
                                    <div class="card rounded-md p-3 mb-1 no-shadow color">
                                        <div class="blue-light"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">LIGHT BLUE</span>
                                    </div>
                                </a>
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="dark-blue" data-parent="color">
                                    <div class="card rounded-md p-3 mb-1 no-shadow color">
                                        <div class="blue-dark"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">DARK BLUE</span>
                                    </div>
                                </a>
                            </div>

                            <div class="row d-flex g-3 justify-content-between flex-wrap mb-3">
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="light-red" data-parent="color">
                                    <div class="card rounded-md p-3 mb-1 no-shadow color">
                                        <div class="red-light"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">LIGHT RED</span>
                                    </div>
                                </a>
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="dark-red" data-parent="color">
                                    <div class="card rounded-md p-3 mb-1 no-shadow color">
                                        <div class="red-dark"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">DARK RED</span>
                                    </div>
                                </a>
                            </div>

                            <div class="row d-flex g-3 justify-content-between flex-wrap mb-3">
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="light-green" data-parent="color">
                                    <div class="card rounded-md p-3 mb-1 no-shadow color">
                                        <div class="green-light"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">LIGHT GREEN</span>
                                    </div>
                                </a>
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="dark-green" data-parent="color">
                                    <div class="card rounded-md p-3 mb-1 no-shadow color">
                                        <div class="green-dark"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">DARK GREEN</span>
                                    </div>
                                </a>
                            </div>

                            <div class="row d-flex g-3 justify-content-between flex-wrap mb-3">
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="light-purple" data-parent="color">
                                    <div class="card rounded-md p-3 mb-1 no-shadow color">
                                        <div class="purple-light"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">LIGHT PURPLE</span>
                                    </div>
                                </a>
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="dark-purple" data-parent="color">
                                    <div class="card rounded-md p-3 mb-1 no-shadow color">
                                        <div class="purple-dark"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">DARK PURPLE</span>
                                    </div>
                                </a>
                            </div>

                            <div class="row d-flex g-3 justify-content-between flex-wrap mb-3">
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="light-pink" data-parent="color">
                                    <div class="card rounded-md p-3 mb-1 no-shadow color">
                                        <div class="pink-light"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">LIGHT PINK</span>
                                    </div>
                                </a>
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="dark-pink" data-parent="color">
                                    <div class="card rounded-md p-3 mb-1 no-shadow color">
                                        <div class="pink-dark"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">DARK PINK</span>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="mb-5" id="navcolor">
                            <label class="mb-3 d-inline-block form-label">Override Nav Palette</label>
                            <div class="row d-flex g-3 justify-content-between flex-wrap">
                                <a href="#" class="flex-grow-1 w-33 option col" data-value="default" data-parent="navcolor">
                                    <div class="card rounded-md p-3 mb-1 no-shadow">
                                        <div class="figure figure-primary top"></div>
                                        <div class="figure figure-secondary bottom"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">DEFAULT</span>
                                    </div>
                                </a>
                                <a href="#" class="flex-grow-1 w-33 option col" data-value="light" data-parent="navcolor">
                                    <div class="card rounded-md p-3 mb-1 no-shadow">
                                        <div class="figure figure-secondary figure-light top"></div>
                                        <div class="figure figure-secondary bottom"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">LIGHT</span>
                                    </div>
                                </a>
                                <a href="#" class="flex-grow-1 w-33 option col" data-value="dark" data-parent="navcolor">
                                    <div class="card rounded-md p-3 mb-1 no-shadow">
                                        <div class="figure figure-muted figure-dark top"></div>
                                        <div class="figure figure-secondary bottom"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">DARK</span>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="mb-5" id="placement">
                            <label class="mb-3 d-inline-block form-label">Menu Placement</label>
                            <div class="row d-flex g-3 justify-content-between flex-wrap">
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="horizontal" data-parent="placement">
                                    <div class="card rounded-md p-3 mb-1 no-shadow">
                                        <div class="figure figure-primary top"></div>
                                        <div class="figure figure-secondary bottom"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">HORIZONTAL</span>
                                    </div>
                                </a>
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="vertical" data-parent="placement">
                                    <div class="card rounded-md p-3 mb-1 no-shadow">
                                        <div class="figure figure-primary left"></div>
                                        <div class="figure figure-secondary right"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">VERTICAL</span>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="mb-5" id="behaviour">
                            <label class="mb-3 d-inline-block form-label">Menu Behaviour</label>
                            <div class="row d-flex g-3 justify-content-between flex-wrap">
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="pinned" data-parent="behaviour">
                                    <div class="card rounded-md p-3 mb-1 no-shadow">
                                        <div class="figure figure-primary left large"></div>
                                        <div class="figure figure-secondary right small"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">PINNED</span>
                                    </div>
                                </a>
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="unpinned" data-parent="behaviour">
                                    <div class="card rounded-md p-3 mb-1 no-shadow">
                                        <div class="figure figure-primary left"></div>
                                        <div class="figure figure-secondary right"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">UNPINNED</span>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="mb-5" id="layout">
                            <label class="mb-3 d-inline-block form-label">Layout</label>
                            <div class="row d-flex g-3 justify-content-between flex-wrap">
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="fluid" data-parent="layout">
                                    <div class="card rounded-md p-3 mb-1 no-shadow">
                                        <div class="figure figure-primary top"></div>
                                        <div class="figure figure-secondary bottom"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">FLUID</span>
                                    </div>
                                </a>
                                <a href="#" class="flex-grow-1 w-50 option col" data-value="boxed" data-parent="layout">
                                    <div class="card rounded-md p-3 mb-1 no-shadow">
                                        <div class="figure figure-primary top"></div>
                                        <div class="figure figure-secondary bottom small"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">BOXED</span>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="mb-5" id="radius">
                            <label class="mb-3 d-inline-block form-label">Radius</label>
                            <div class="row d-flex g-3 justify-content-between flex-wrap">
                                <a href="#" class="flex-grow-1 w-33 option col" data-value="rounded" data-parent="radius">
                                    <div class="card rounded-md radius-rounded p-3 mb-1 no-shadow">
                                        <div class="figure figure-primary top"></div>
                                        <div class="figure figure-secondary bottom"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">ROUNDED</span>
                                    </div>
                                </a>
                                <a href="#" class="flex-grow-1 w-33 option col" data-value="standard" data-parent="radius">
                                    <div class="card rounded-md radius-regular p-3 mb-1 no-shadow">
                                        <div class="figure figure-primary top"></div>
                                        <div class="figure figure-secondary bottom"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">STANDARD</span>
                                    </div>
                                </a>
                                <a href="#" class="flex-grow-1 w-33 option col" data-value="flat" data-parent="radius">
                                    <div class="card rounded-md radius-flat p-3 mb-1 no-shadow">
                                        <div class="figure figure-primary top"></div>
                                        <div class="figure figure-secondary bottom"></div>
                                    </div>
                                    <div class="text-muted text-part">
                                        <span class="text-extra-small align-middle">FLAT</span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Theme Settings Modal End -->

    <!-- Niches Modal Start -->
    <div class="modal fade modal-right scroll-out-negative" id="niches" data-bs-backdrop="true" tabindex="-1" role="dialog" aria-labelledby="niches" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable full" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Niches</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="scroll-track-visible">
                        <div class="mb-5">
                            <label class="mb-2 d-inline-block form-label">Classic Dashboard</label>
                            <div class="hover-reveal-buttons position-relative hover-reveal cursor-default">
                                <div class="position-relative mb-3 mb-lg-5 rounded-sm">
                                    <img src="https://acorn.coloredstrategies.com/img/page/classic-dashboard.jpg" class="img-fluid rounded-sm lower-opacity border border-separator-light" alt="card image" />
                                    <div class="position-absolute reveal-content rounded-sm absolute-center-vertical text-center w-100">
                                        <a target="_blank" href="https://acorn-html-classic-dashboard.coloredstrategies.com/" class="btn btn-primary btn-sm sw-10 sw-lg-12 d-block mx-auto my-1">
                                            Html
                                        </a>
                                        <a target="_blank" href="https://acorn-laravel-classic-dashboard.coloredstrategies.com/" class="btn btn-primary btn-sm sw-10 sw-lg-12 d-block mx-auto my-1">
                                            Laravel
                                        </a>
                                        <a target="_blank" href="https://acorn-dotnet-classic-dashboard.coloredstrategies.com/" class="btn btn-primary btn-sm sw-10 sw-lg-12 d-block mx-auto my-1">
                                            .Net5
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mb-5">
                            <label class="mb-2 d-inline-block form-label">Ecommerce Platform</label>
                            <div class="hover-reveal-buttons position-relative hover-reveal cursor-default">
                                <div class="position-relative mb-3 mb-lg-5 rounded-sm">
                                    <img src="https://acorn.coloredstrategies.com/img/page/ecommerce-platform.jpg" class="img-fluid rounded-sm lower-opacity border border-separator-light" alt="card image" />
                                    <div class="position-absolute reveal-content rounded-sm absolute-center-vertical text-center w-100">
                                        <a target="_blank" href="https://acorn-html-ecommerce-platform.coloredstrategies.com/" class="btn btn-primary btn-sm sw-10 sw-lg-12 d-block mx-auto my-1">
                                            Html
                                        </a>
                                        <a target="_blank" href="https://acorn-laravel-ecommerce-platform.coloredstrategies.com/" class="btn btn-primary btn-sm sw-10 sw-lg-12 d-block mx-auto my-1">
                                            Laravel
                                        </a>
                                        <a target="_blank" href="https://acorn-dotnet-ecommerce-platform.coloredstrategies.com/" class="btn btn-primary btn-sm sw-10 sw-lg-12 d-block mx-auto my-1">
                                            .Net5
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mb-5">
                            <label class="mb-2 d-inline-block form-label">Elearning Portal</label>
                            <div class="hover-reveal-buttons position-relative hover-reveal cursor-default">
                                <div class="position-relative mb-3 mb-lg-5 rounded-sm">
                                    <img src="https://acorn.coloredstrategies.com/img/page/elearning-portal.jpg" class="img-fluid rounded-sm lower-opacity border border-separator-light" alt="card image" />
                                    <div class="position-absolute reveal-content rounded-sm absolute-center-vertical text-center w-100">
                                        <a target="_blank" href="https://acorn-html-elearning-portal.coloredstrategies.com/" class="btn btn-primary btn-sm sw-10 sw-lg-12 d-block mx-auto my-1">
                                            Html
                                        </a>
                                        <a target="_blank" href="https://acorn-laravel-elearning-portal.coloredstrategies.com/" class="btn btn-primary btn-sm sw-10 sw-lg-12 d-block mx-auto my-1">
                                            Laravel
                                        </a>
                                        <a target="_blank" href="https://acorn-dotnet-elearning-portal.coloredstrategies.com/" class="btn btn-primary btn-sm sw-10 sw-lg-12 d-block mx-auto my-1">
                                            .Net5
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mb-5">
                            <label class="mb-2 d-inline-block form-label">Service Provider</label>
                            <div class="hover-reveal-buttons position-relative hover-reveal cursor-default">
                                <div class="position-relative mb-3 mb-lg-5 rounded-sm">
                                    <img src="https://acorn.coloredstrategies.com/img/page/service-provider.jpg" class="img-fluid rounded-sm lower-opacity border border-separator-light" alt="card image" />
                                    <div class="position-absolute reveal-content rounded-sm absolute-center-vertical text-center w-100">
                                        <a target="_blank" href="https://acorn-html-service-provider.coloredstrategies.com/" class="btn btn-primary btn-sm sw-10 sw-lg-12 d-block mx-auto my-1">
                                            Html
                                        </a>
                                        <a target="_blank" href="https://acorn-laravel-service-provider.coloredstrategies.com/" class="btn btn-primary btn-sm sw-10 sw-lg-12 d-block mx-auto my-1">
                                            Laravel
                                        </a>
                                        <a target="_blank" href="https://acorn-dotnet-service-provider.coloredstrategies.com/" class="btn btn-primary btn-sm sw-10 sw-lg-12 d-block mx-auto my-1">
                                            .Net5
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mb-5">
                            <label class="mb-2 d-inline-block form-label">Starter Project</label>
                            <div class="hover-reveal-buttons position-relative hover-reveal cursor-default">
                                <div class="position-relative mb-3 mb-lg-5 rounded-sm">
                                    <img src="https://acorn.coloredstrategies.com/img/page/starter-project.jpg" class="img-fluid rounded-sm lower-opacity border border-separator-light" alt="card image" />
                                    <div class="position-absolute reveal-content rounded-sm absolute-center-vertical text-center w-100">
                                        <a target="_blank" href="https://acorn-html-starter-project.coloredstrategies.com/" class="btn btn-primary btn-sm sw-10 sw-lg-12 d-block mx-auto my-1">
                                            Html
                                        </a>
                                        <a target="_blank" href="https://acorn-laravel-starter-project.coloredstrategies.com/" class="btn btn-primary btn-sm sw-10 sw-lg-12 d-block mx-auto my-1">
                                            Laravel
                                        </a>
                                        <a target="_blank" href="https://acorn-dotnet-starter-project.coloredstrategies.com/" class="btn btn-primary btn-sm sw-10 sw-lg-12 d-block mx-auto my-1">
                                            .Net5
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Niches Modal End -->

    <!-- Theme Settings & Niches Buttons Start -->
    <div class="settings-buttons-container">
        <button type="button" class="btn settings-button btn-primary p-0" data-bs-toggle="modal" data-bs-target="#settings" id="settingsButton">
            <span class="d-inline-block no-delay" data-bs-delay="0" data-bs-offset="0,3" data-bs-toggle="tooltip" data-bs-placement="left" title="Settings">
                <i data-cs-icon="paint-roller" class="position-relative"></i>
            </span>
        </button>
        <button type="button" class="btn settings-button btn-primary p-0" data-bs-toggle="modal" data-bs-target="#niches" id="nichesButton">
            <span class="d-inline-block no-delay" data-bs-delay="0" data-bs-offset="0,3" data-bs-toggle="tooltip" data-bs-placement="left" title="Niches">
                <i data-cs-icon="toy" class="position-relative"></i>
            </span>
        </button>
        <a href="https://1.envato.market/BX5oGy" target="_blank" class="btn settings-button btn-primary p-0" id="purchaseButton">
            <span class="d-inline-block no-delay" data-bs-delay="0" data-bs-offset="0,3" data-bs-toggle="tooltip" data-bs-placement="left" title="Purchase">
                <i data-cs-icon="cart" class="position-relative"></i>
            </span>
        </a>
    </div>
    <!-- Theme Settings & Niches Buttons End -->

    <!-- Search Modal Start -->
    <div class="modal fade modal-under-nav modal-search modal-close-out" id="searchPagesModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header border-0 p-0">
                    <button type="button" class="btn-close btn btn-icon btn-icon-only btn-foreground" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body ps-5 pe-5 pb-0 border-0">
                    <input id="searchPagesInput" class="form-control form-control-xl borderless ps-0 pe-0 mb-1 auto-complete" type="text" autocomplete="off" />
                </div>
                <div class="modal-footer border-top justify-content-start ps-5 pe-5 pb-3 pt-3 border-0">
                    <span class="text-alternate d-inline-block m-0 me-3">
                        <i data-cs-icon="arrow-bottom" data-cs-size="15" class="text-alternate align-middle me-1"></i>
                        <span class="align-middle text-medium">Navigate</span>
                    </span>
                    <span class="text-alternate d-inline-block m-0 me-3">
                        <i data-cs-icon="arrow-bottom-left" data-cs-size="15" class="text-alternate align-middle me-1"></i>
                        <span class="align-middle text-medium">Select</span>
                    </span>
                </div>
            </div>
        </div>
    </div>
    <!-- Search Modal End -->

    <!-- Vendor Scripts Start -->
    <script src="<?php echo e(asset('/')); ?>js/vendor/jquery-3.5.1.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/vendor/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/vendor/OverlayScrollbars.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/vendor/autoComplete.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/vendor/clamp.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/vendor/baguetteBox.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/cs/responsivetab.js"></script>
    <!-- Vendor Scripts End -->

    <!-- Template Base Scripts Start -->
    <script src="<?php echo e(asset('/')); ?>font/CS-Line/csicons.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/base/helpers.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/base/globals.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/base/nav.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/base/search.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/base/settings.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/base/init.js"></script>
    <!-- Template Base Scripts End -->
    <!-- Page Specific Scripts Start -->
    <script src="<?php echo e(asset('/')); ?>js/pages/portfolio.home.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/common.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/scripts.js"></script>
    <!-- Page Specific Scripts End -->
</body>

</html><?php /**PATH /Users/bandrigotalai/Documents/My Personal File/Project/IAIN KENDARI/tracer/resources/views/template-user.blade.php ENDPATH**/ ?>