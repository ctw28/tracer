<?php $__env->startSection('content'); ?>

<!-- Form Row Start -->
<!-- Text Content Start -->
<section class="scroll-section" id="textContent">
    <div class="card mb-5">
        <div class="card-body d-flex flex-column">
            <h3 class="card-title mb-4">Statistik Kuisioner</h3>
            <select class="form-select" id="bagian">
                <option value="">Pilih Bagian</option>
                <?php $__currentLoopData = $bagian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->step_kode ." - ". $item->step_nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div id="show-pertanyaan">

            </div>
        </div>
    </div>
</section>
<!-- Text Content End -->
<section class="scroll-section" id="formRow" style="display:none">
    <div class="card mb-5">
        <div class="card-body">
            <h4>Filter</h4>
            <div class="row mb-5">

                <div class="col-md-4">
                    <select class="form-select" id="fakultas">
                    </select>
                </div>
                <div class="col-md-4">
                    <select class="form-select" id="prodi">
                    </select>
                </div>
                <div class="col-md-4">
                    <button class="btn btn-warning" id="filter">Filter</button>

                </div>
            </div>
            <h2>Rekap</h2>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Pilihan Jawaban</th>
                        <th scope="col">Total</th>
                    </tr>
                </thead>
                <tbody id="show-data-table">

                </tbody>
            </table>

            <h2>Diagram</h2>
            <div>
                <label class="form-label d-block">Pilih Diagram</label>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="diagram" id="pie" value="pie" />
                    <label class="form-check-label" for="pie">Pie</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="diagram" id="bar" value="bar" />
                    <label class="form-check-label" for="bar">Bar</label>
                </div>
                <div class="form-check form-check-inline">
                    <button class="btn btn-primary" id="terapkan">Terapkan</button>
                </div>
            </div>
            <div id="showDiagram" class="col-sm-12" style="height: 500px;"></div>
        </div>
    </div>
</section>
<!-- Form Row End -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script>
    let bagian = document.querySelector("#bagian")

    bagian.addEventListener('change', async function() {
        document.querySelector("#formRow").style.display = 'none'

        // return alert("gg")
        let url = "<?php echo e(route('admin.get.pertanyaan',':bagianId')); ?>"
        url = url.replace(':bagianId', `${bagian.options[bagian.selectedIndex].value}`)
        response = await fetch(url)
        responseMessage = await response.json()
        let showPertanyaan = document.querySelector("#show-pertanyaan")
        showPertanyaan.innerHTML = ""
        let select = document.createElement('select');
        select.className = "form-select mt-2"
        select.id = "pertanyaan"
        let option = document.createElement('option')
        option.innerText = "Pilih Pertanyaan"
        option.value = ""
        select.appendChild(option)
        responseMessage.forEach(function(data, i) {
            let option = document.createElement('option')
            option.innerText = data.pertanyaan
            option.value = data.id
            select.appendChild(option)
        });
        showPertanyaan.appendChild(select)
        console.log(responseMessage);
        let pertanyaan = document.querySelector("#pertanyaan")

        pertanyaan.addEventListener("change", async function() {
            let showDataTable = document.querySelector("#show-data-table")
            if (pertanyaan.options[pertanyaan.selectedIndex].value == "") {
                document.querySelector("#formRow").style.display = 'none'
                showDataTable.innerHTML = ""
                return
            }
            showDataTable.innerHTML = ""
            let dataForm = new FormData()
            dataForm.append('pertanyaanId', pertanyaan.options[pertanyaan.selectedIndex].value)
            dataForm.append('usersId', [])
            url2 = "<?php echo e(route('admin.get.count.pertanyaan')); ?>"
            response2 = await fetch(url2, {
                method: "POST",
                body: dataForm
            })
            // console.log(responseMessage2.dataPertanyaan[0].jawaban_jenis);
            responseMessage2 = await response2.json()
            // return console.log(responseMessage2);

            let fragment = document.createDocumentFragment();
            responseMessage2.dataPertanyaan[0].jawaban_jenis.forEach(function(data, i) {
                let tr = document.createElement('tr');
                let nomor = document.createElement('td');
                nomor.innerText = i + 1
                let pilihanJawaban = document.createElement('td');
                pilihanJawaban.innerText = data.pilihan_jawaban
                let total = document.createElement('td');
                total.innerText = data.total
                tr.appendChild(nomor)
                tr.appendChild(pilihanJawaban)
                tr.appendChild(total)
                fragment.appendChild(tr);
            });
            showDataTable.appendChild(fragment)
            let daftarJawaban = responseMessage2.dataPertanyaan[0].jawaban_jenis
            google.charts.load('current', {
                'packages': ['corechart', 'bar']
            });
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
                let jawaban = [
                    ['Task', pertanyaan.options[pertanyaan.selectedIndex].innerText]
                ]
                daftarJawaban.map(function(data) {
                    jawaban.push([data.pilihan_jawaban, data.total])
                });
                console.log(jawaban);
                var data = google.visualization.arrayToDataTable(
                    jawaban
                );
                var options = {
                    title: pertanyaan.options[pertanyaan.selectedIndex].innerText,
                    sliceVisibilityThreshold: 0,
                    pieHole: 0.4,
                };

                document.querySelector("#formRow").style.display = 'block'
                document.getElementById('showDiagram').innerHTML = ""
                document.querySelector("#terapkan").addEventListener("click", function() {
                    let diagram = document.querySelector('input[name="diagram"]:checked').value;
                    var chart
                    if (diagram == "pie")
                        chart = new google.visualization.PieChart(document.getElementById('showDiagram'));
                    if (diagram == "bar")
                        chart = new google.visualization.BarChart(document.getElementById('showDiagram'));
                    chart.innerHTML = ""
                    chart.draw(data, options);
                });
            }
            let fakultas = document.querySelector("#fakultas")
            let prodi = document.querySelector("#prodi")
            setDefaultPilihan(fakultas)
            setDefaultPilihan(prodi)

            prodi.disabled = true
            // data-fakultas
            getFakultas();
            async function getFakultas() {
                response = await fetch('https://sia.iainkendari.ac.id/data-fakultas')
                responseMessage = await response.json()
                console.log(responseMessage);
                let fragment = document.createDocumentFragment();
                let showDataTable = document.querySelector("#show-data-table")

                responseMessage.forEach(function(data, i) {
                    let option = document.createElement('option');
                    option.innerText = `${data.singkatan} - Fakultas ${data.nama}`
                    option.value = data.idfakultas
                    fragment.appendChild(option);
                })
                fakultas.appendChild(fragment)
            }


            fakultas.addEventListener('change', async function() {
                setDefaultPilihan(prodi)
                if (fakultas.options[fakultas.selectedIndex].value == "semua" || fakultas.options[fakultas.selectedIndex].value == "")
                    return prodi.disabled = true
                else
                    prodi.disabled = false

                response = await fetch(`https://sia.iainkendari.ac.id/data-prodi/${fakultas.options[fakultas.selectedIndex].value}`)
                responseMessage = await response.json()
                console.log(responseMessage);
                responseMessage.forEach(function(data, i) {
                    let option = document.createElement('option');
                    option.innerText = `${data.singkatan} - ${data.prodi}`
                    option.value = data.idprodi
                    fragment.appendChild(option);
                })
                prodi.appendChild(fragment)
            })
        });
        document.querySelector("#filter").addEventListener('click', async function() {
            let dataWhere = {};
            if (fakultas.options[fakultas.selectedIndex].value != "" && fakultas.options[fakultas.selectedIndex].value != "semua")
                dataWhere["tb_mstprodi.idfakultas"] = fakultas.options[fakultas.selectedIndex].value;
            if (prodi.options[prodi.selectedIndex].value != "" && fakultas.options[fakultas.selectedIndex].value != "semua")
                dataWhere["tb_data.idprodi"] = prodi.options[prodi.selectedIndex].value;

            let dataId = []
            let dataUser = <?php echo json_encode($dataUser, 15, 512) ?>;
            dataUser.forEach(function(data) {
                dataId.push(data.name);
            });

            let dataSend = new FormData()
            dataSend.append('iddata', JSON.stringify(dataId))
            dataSend.append('where', JSON.stringify(dataWhere))
            response = await fetch('https://sia.iainkendari.ac.id/get-id-data', {
                method: "POST",
                body: dataSend
            })
            responseMessage = await response.json()
            dataId = []
            responseMessage.data.forEach(function(data) {
                dataId.push(data.iddata);
            });
            console.log(dataId);
            let dataSend2 = new FormData()
            let dataSend3 = new FormData()
            dataSend2.append('iddata', JSON.stringify(dataId))
            response = await fetch('<?php echo e(route("admin.get.users")); ?>', {
                method: "POST",
                body: dataSend2
            })
            console.log("=-----");
            responseMessage = await response.json()
            let usersid = []
            responseMessage.forEach(function(data) {
                usersid.push(data.id)
            })
            console.log(usersid);
            dataSend3.append('pertanyaanId', pertanyaan.options[pertanyaan.selectedIndex].value)
            dataSend3.append('usersId', JSON.stringify(usersid))
            url2 = "<?php echo e(route('admin.get.count.pertanyaan')); ?>"
            response2 = await fetch(url2, {
                method: "POST",
                body: dataSend3
            })
            responseMessage2 = await response2.json()
            console.log(responseMessage2);
            // console.log(responseMessage2.dataPertanyaan[0].jawaban_jenis);
            let showDataTable = document.querySelector("#show-data-table")
            showDataTable.innerHTML = ""
            let fragment = document.createDocumentFragment();
            responseMessage2.dataPertanyaan[0].jawaban_jenis.forEach(function(data, i) {
                let tr = document.createElement('tr');
                let nomor = document.createElement('td');
                nomor.innerText = i + 1
                let pilihanJawaban = document.createElement('td');
                pilihanJawaban.innerText = data.pilihan_jawaban
                let total = document.createElement('td');
                total.innerText = data.total
                tr.appendChild(nomor)
                tr.appendChild(pilihanJawaban)
                tr.appendChild(total)
                fragment.appendChild(tr);
            });
            showDataTable.appendChild(fragment)
            let daftarJawaban = responseMessage2.dataPertanyaan[0].jawaban_jenis
            google.charts.load('current', {
                'packages': ['corechart', 'bar']
            });
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
                let jawaban = [
                    ['Task', pertanyaan.options[pertanyaan.selectedIndex].innerText]
                ]
                daftarJawaban.map(function(data) {
                    jawaban.push([data.pilihan_jawaban, data.total])
                });
                console.log(jawaban);
                var data = google.visualization.arrayToDataTable(
                    jawaban
                );
                var options = {
                    title: pertanyaan.options[pertanyaan.selectedIndex].innerText,
                    sliceVisibilityThreshold: 0,
                    pieHole: 0.4,
                };

                document.querySelector("#formRow").style.display = 'block'
                document.getElementById('showDiagram').innerHTML = ""
                document.querySelector("#terapkan").addEventListener("click", function() {
                    let diagram = document.querySelector('input[name="diagram"]:checked').value;
                    var chart
                    if (diagram == "pie")
                        chart = new google.visualization.PieChart(document.getElementById('showDiagram'));
                    if (diagram == "bar")
                        chart = new google.visualization.BarChart(document.getElementById('showDiagram'));
                    chart.innerHTML = ""
                    chart.draw(data, options);
                });
            }
            console.log(responseMessage);
        });

        // {
        // }
    });

    function setDefaultPilihan(pilihan) {
        pilihan.innerHTML = ""
        let optionPilih = document.createElement('option');
        optionPilih.innerText = "Pilih Prodi"
        optionPilih.value = ""
        prodi.appendChild(optionPilih)
        let optionSemua = document.createElement('option');
        optionSemua.innerText = "Semua Prodi"
        optionSemua.value = "semua"
        pilihan.appendChild(optionSemua)
    }

    function setStatistikData() {

    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bandrigotalai/Documents/My Personal File/Project/IAIN KENDARI/tracer/resources/views/admin/statistik.blade.php ENDPATH**/ ?>