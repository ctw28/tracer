<?php $__env->startSection('content'); ?>

<section class="scroll-section" id="basic">
    <!-- Basic Start -->
    <h2 class="small-title"><?php echo e($pertanyaan->step_kode); ?>. <?php echo e($pertanyaan->step_nama); ?></h2>
    <div class="card mb-5">
        <div class="card-body">
            <form action="<?php echo e(route('admin.set.form.create',$pertanyaan->id)); ?>" method="post" enctype="multipart/form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="step_id" value="<?php echo e($pertanyaan->id); ?>">
                <?php $__currentLoopData = $pertanyaan->pertanyaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tanya): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $tanya->form; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
</section>
<!-- Basic End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bandrigotalai/Documents/My Personal File/Project/IAIN KENDARI/tracer/resources/views/user/form.blade.php ENDPATH**/ ?>